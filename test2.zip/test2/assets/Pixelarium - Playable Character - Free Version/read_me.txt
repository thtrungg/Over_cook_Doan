Thanks for downloading Pixelarium - Playable Character 16x16!

I'll be updating this asset, adding new animations! Also, Pixelarium is going to be a full bundle with different scenarios and environments. enemies and characters pack. So! stay tuned for future content.

License - Free Version
  - You can only use these assets in non-commercial projects.
  - You can modify the assets.
  - You can not redistribute or resale, even if modified.

Follow me on twitter if you're interested in future content!

https://twitter.com/LukeThePolice

If you enjoy it, please leave a rating and a comment, i'll be very grateful!